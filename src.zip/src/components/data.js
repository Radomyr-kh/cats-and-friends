export const itemData = [
  {
    img: 'cat1.jfif',
    title: 'Shyster',
  },
  {
    img: 'cat2.jpg',
    title: 'Lazy',
  },
  {
    img: 'cat3.jfif',
    title: 'Brandy',
  },
  {
    img: 'cat4.jpg',
    title: 'Milk',
  },
  {
    img: 'cat5.jpg',
    title: 'Blinds',
  },
  {
    img: 'cat6.jpg',
    title: 'Charles',
  },
  {
    img: 'cat7.jpg',
    title: 'Laptop',
  },
  {
    img: 'cat8.jpg',
    title: 'Dorothy',
  },
  {
    img: 'cat9.jpg',
    title: 'Feather',
  },
  {
    img: 'cat10.jpg',
    title: 'Storm',
  },
  {
    img: 'cat11.jpg',
    title: 'Candy',
  },
  {
    img: 'cat12.jpg',
    title: 'Sporty',
  },
  {
    img: 'cat13.jpg',
    title: 'Fluffy',
  },
];
